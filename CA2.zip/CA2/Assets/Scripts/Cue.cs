﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(MeshCollider))]
public class Cue : MonoBehaviour {

    public Rigidbody cue;
    public float speed;

    void Update()
    {
        Invoke("HitBall", 1f);
        ActivateCue();
    }

    private void HitBall()
    {
        cue.AddForce(new Vector3(0f, 0f, speed), ForceMode.Impulse);
        cue.gameObject.SetActive(false);
    }

    private void ActivateCue()
    {
        if (speed < 1)
        {
            cue.gameObject.SetActive(true);
        }
    }

}

// Turn off gravity and kinematic to use this
//   private Rigidbody cue;
//   public float speed;

//// Use this for initialization
//void Start () {
//       cue = GetComponent<Rigidbody>();
//   }

//// Update is called once per frame
//void Update () {
//       float moveHorizontal = Input.GetAxis("Horizontal");
//       float moveVertical = Input.GetAxis("Vertical");

//       Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);

//       cue.AddForce(movement * speed);
//   }



//if (Input.GetKey(KeyCode.W))
//{
//    transform.position += Vector3.forward * Time.deltaTime * speed;
//}
//else if (Input.GetKey(KeyCode.S))
//{
//    cue.position += Vector3.back * Time.deltaTime * speed;
//}
//else if (Input.GetKey(KeyCode.A))
//{
//    cue.position += Vector3.left * Time.deltaTime * speed;
//}
//else if (Input.GetKey(KeyCode.D))
//{
//    cue.position += Vector3.right * Time.deltaTime * speed;
//}

//if (Input.GetKey(KeyCode.E))
//{
//    transform.Rotate(0, Time.deltaTime * clockwise, 0);
//}
//else if (Input.GetKey(KeyCode.Q))
//{
//    transform.Rotate(0, Time.deltaTime * counterClockwise, 0);
//}


//void OnMouseDrag()
//{
//    float moveHorizontal = Input.GetAxis("Horizontal");
//    float moveVertical = Input.GetAxis("Vertical");

//    float distance_to_screen = Camera.main.WorldToScreenPoint(gameObject.transform.position).z;
//    Vector3 movement = new Vector3(moveHorizontal, 0, moveVertical);
//    transform.position = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, distance_to_screen));

//}