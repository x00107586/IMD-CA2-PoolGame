﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Balls : MonoBehaviour {

    //public Text countText1;
    //private int count1;

    //// Use this for initialization
    //void Start () {
    //    count1 = 0;
    //    SetCountValueSpots();
    //}

    //void OnTriggerEnter(Collider other)
    //{

    //    if (other.gameObject.name == "Pockets")
    //    {
    //        count1++;
    //    }

    //    SetCountValueSpots();
    //}

    //void SetCountValueSpots()
    //{
    //    countText1.text = "Spot Score: " + count1.ToString();
    //}
}
